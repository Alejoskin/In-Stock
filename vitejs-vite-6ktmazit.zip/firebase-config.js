
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import{getAuth} from 'firebase/auth';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCahz_F6t0SxEHoIcPrOrnQ15V2PYsIPAA",
  authDomain: "testingforclass-ff566.firebaseapp.com",
  projectId: "testingforclass-ff566",
  storageBucket: "testingforclass-ff566.firebasestorage.app",
  messagingSenderId: "708862844319",
  appId: "1:708862844319:web:2027f25db1cbe19f16b1aa",
  measurementId: "G-E4XFJGBYLQ"
};

//init firebase
const app= initializeApp(firebaseConfig);
const auth = getAuth(app);

export default auth; 