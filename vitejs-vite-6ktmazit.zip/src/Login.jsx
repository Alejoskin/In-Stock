import React, { useState } from 'react';
import './App.css';

import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import auth from '../firebase-config'; 
import { useNavigate } from 'react-router-dom';

//definicion del componente funcional de login
function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const [loginError, setLogError ]= useState(true); //set el error 

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password); //espera po la respiesta a ver si el usaurio es valido

      navigate('/');

      console.log('User signed in');
    } catch (error) {
      setLogError(false);
      console.error('Login Failed:', error.message);
    }
  };

  const handleRegister = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);

      navigate('/');

      console.log('User Registered');
    } catch (error) {
      setLogError(false);
      console.error('Registration Failed:', error.message);
    }
  };

  return (
    <div>
      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email" />
      <br />
      <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
      <br />
      <button onClick={handleLogin}>Login</button>
      <br />
      <button onClick={handleRegister}>Register</button>
      <br />
      
      {loginError ? <p> </p> : <h3> Wrong username or password.</h3>}
    </div>
  );
}

export default Login;
